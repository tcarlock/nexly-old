require 'test_helper'

class RecommendationMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
