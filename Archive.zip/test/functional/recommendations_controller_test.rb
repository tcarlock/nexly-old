require 'test_helper'

class RecommendationsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
