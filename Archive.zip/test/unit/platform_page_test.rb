require 'test_helper'

class PlatformPageTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

# == Schema Information
#
# Table name: platform_pages
#
#  id          :integer(4)      not null, primary key
#  platform_id :integer(4)
#  business_id :integer(4)
#  external_id :string(255)
#  created_at  :datetime
#  updated_at  :datetime
#

