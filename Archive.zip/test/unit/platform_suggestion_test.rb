require 'test_helper'

class PlatformSuggestionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

# == Schema Information
#
# Table name: platform_suggestions
#
#  id         :integer(4)      not null, primary key
#  url        :string(255)
#  created_at :datetime
#  updated_at :datetime
#

