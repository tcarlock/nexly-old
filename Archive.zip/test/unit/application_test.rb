require 'test_helper'

class ApplicationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

# == Schema Information
#
# Table name: applications
#
#  id         :integer(4)      not null, primary key
#  title      :string(255)
#  details    :text
#  price      :float
#  is_public  :boolean(1)      default(TRUE)
#  created_at :datetime
#  updated_at :datetime
#

