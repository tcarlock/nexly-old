require 'test_helper'

class PluginsHelperTest < ActionView::TestCase
end
