require 'test_helper'

class PlatformPagesHelperTest < ActionView::TestCase
end
