require 'test_helper'

class AuthenticationsHelperTest < ActionView::TestCase
end
