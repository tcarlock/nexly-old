require 'test_helper'

class BusinessesHelperTest < ActionView::TestCase
end
