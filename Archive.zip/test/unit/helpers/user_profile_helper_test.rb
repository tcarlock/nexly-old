require 'test_helper'

class UserProfileHelperTest < ActionView::TestCase
end
