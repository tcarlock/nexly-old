require 'test_helper'

class AppSubscriptionsHelperTest < ActionView::TestCase
end
