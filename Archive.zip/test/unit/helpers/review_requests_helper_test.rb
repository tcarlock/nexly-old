require 'test_helper'

class ReviewRequestsHelperTest < ActionView::TestCase
end
