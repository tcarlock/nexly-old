require 'test_helper'

class AnalyticsHelperTest < ActionView::TestCase
end
