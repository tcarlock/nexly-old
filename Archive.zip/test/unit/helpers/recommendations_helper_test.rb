require 'test_helper'

class RecommendationsHelperTest < ActionView::TestCase
end
