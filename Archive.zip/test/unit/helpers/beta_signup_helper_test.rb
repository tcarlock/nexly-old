require 'test_helper'

class BetaSignupHelperTest < ActionView::TestCase
end
