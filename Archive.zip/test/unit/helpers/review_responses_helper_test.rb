require 'test_helper'

class ReviewResponsesHelperTest < ActionView::TestCase
end
