module BetaSignupHelper
end
