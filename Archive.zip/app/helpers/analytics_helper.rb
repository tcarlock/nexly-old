module AnalyticsHelper
end
