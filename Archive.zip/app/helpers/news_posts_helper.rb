module NewsPostsHelper
end
