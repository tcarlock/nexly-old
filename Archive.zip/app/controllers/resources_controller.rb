class ResourcesController < ApplicationController
  def create
  end

  def new
  end

  def update
  end

  def destroy
  end

end
