# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Nexly::Application.config.secret_token = 'd2b97c0ff7f86fa47c0356a46944574b3a158209b80b259da533d43840ec4970c5a8cf0ef9d9bc65f6f698e5393fcf32eea07913608480b3b5531f02f5a780f7'
