class AddIndustryIdToBusiness < ActiveRecord::Migration
  def change
  end
end
