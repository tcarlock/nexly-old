require 'spec_helper'

describe UserProfileController do

end
